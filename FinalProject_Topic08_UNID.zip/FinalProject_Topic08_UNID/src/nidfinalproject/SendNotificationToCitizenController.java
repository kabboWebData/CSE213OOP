
package nidfinalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.budget;
import nidfinalproject.javaClass.reRegistration;

public class SendNotificationToCitizenController implements Initializable {

    @FXML
    private TextField nameTextField;
    @FXML
    private TextField nidNumberTextField;
    @FXML
    private TextField addressTextField;
    @FXML
    private DatePicker dateOfBirthDatePicker;
    @FXML
    private RadioButton maleRadioButton;
    @FXML
    private RadioButton femaleRadioButton;
    @FXML
    private RadioButton validRadioButton;
    @FXML
    private RadioButton invalidRadioButton;
    
    ArrayList<reRegistration> list = new ArrayList<reRegistration>();

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        maleRadioButton.setSelected(true);
        validRadioButton.setSelected(true);
    }    

    @FXML
    private void notificatioSendButton(ActionEvent event) {
        
         String name = nameTextField.getText();
         String address = addressTextField.getText();
        String registrationOver = maleRadioButton.isSelected()? "Male": "Female" ;
        String reRegistrationFee = validRadioButton.isSelected()? "Valid": "Invalid";
        int nidNumber = Integer.parseInt(nidNumberTextField.getText());
        LocalDate dateOfBirth = dateOfBirthDatePicker.getValue();
        
        nameTextField.setText(null); addressTextField.setText(null);
        dateOfBirthDatePicker.setValue(null); 
        nidNumberTextField.setText(null);
        maleRadioButton.setSelected(false); validRadioButton.setSelected(false);
        femaleRadioButton.setSelected(false); invalidRadioButton.setSelected(false);
        
        
        
        FileOutputStream fis=null;
        ObjectOutputStream ois= null;
        budget bud = null;
        
        try {
            File f= new File("Information Validity Check And Send Notification To Citizen.bin");
            if(f.exists())
            {
                fis = new FileOutputStream(f,true);
               ois= new ObjectOutputStream(fis);
               
               
               //skd = (field)ois.readObject();
                    //skd = (field)ois.readObject();
                    //Object obj = ois.readObject();
                    //obj.submitReport();
                   bud.submitReport();
                    System.out.println(bud.toString());
                   //.appendText(skd.toString());

            }
            else
           {
               fis = new FileOutputStream(f);
               ois= new ObjectOutputStream(fis);
           
           }  
            
           
            
            Iterable<reRegistration> list = null;
          
            for(reRegistration a: list)
            {
                ois.writeObject(a);
            }
            ois.close();
            
        //Alert alt = new Alert(Alert.AlertType.WARNING);
        //alt.setTitle("Warning Alert");
        //alt.setContentText(alt.toString());
        //alt.setHeaderText(null);
        //alt.showAndWait();  
        
        //try{
           // ois.writeObject(alt);
        //}
        //catch(IOException e){
        //alt.setTitle("Warning Alert");
        //alt.setContentText(alt.toString());
        //alt.setHeaderText(null);
        //alt.showAndWait();  
            
        //}
            
            
        } 
        
                  
        
        catch (FileNotFoundException ex) {
            
            

            Logger.getLogger(ApproveReRegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ApproveReRegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }


        
    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }
    
}
