
package nidfinalproject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.Reissue;
import nidfinalproject.javaClass.Tax;


public class CanApproveRetrieveLostNidCardController implements Initializable {

    @FXML
    private TextField nameTxt;
    @FXML
    private TextField nidNumberTxt;
    @FXML
    private TextField gdNumberTxt;
    @FXML
    private TextField thanaNameTxt;
    @FXML
    private TextField districtNameTxt;
    @FXML
    private DatePicker dateOfGdDatePicker;
    @FXML
    private DatePicker dateOfBirthDatePicker;
    @FXML
    private TextArea lostView;
    
        ArrayList<Reissue> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<Reissue> list;
    }    

    @FXML
    private void approveAllFieldsAndAddToArray(ActionEvent event) {
        Reissue std = new Reissue(
       nameTxt.getText(),
       nidNumberTxt.getText(),
       gdNumberTxt.getText(),
       thanaNameTxt.getText(),
       districtNameTxt.getText(),
       dateOfGdDatePicker.getValue(),
       dateOfBirthDatePicker.getValue()
        );
        
        
        nameTxt.setText(null);  nidNumberTxt.setText(null);  gdNumberTxt.setText(null);  thanaNameTxt.setText(null);
         districtNameTxt.setText(null);  dateOfGdDatePicker.setValue(null);  dateOfBirthDatePicker.setValue(null);
         
         try{
            FileOutputStream fos = new FileOutputStream("ApproveRetrieveLostNidCard.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}




    }

    @FXML
    private void readTheApprovingAllInformationButton(ActionEvent event) {
        try {
             Reissue s;
            FileInputStream fis = new FileInputStream("ApproveRetrieveLostNidCard.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (Reissue) ois.readObject();
                //studArr.add((Student) ois.readObject());
                lostView.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }


    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }
    
}
