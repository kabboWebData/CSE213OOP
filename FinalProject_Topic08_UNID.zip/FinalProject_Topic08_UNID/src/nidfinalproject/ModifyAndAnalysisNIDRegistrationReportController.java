
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.text.Document;
import nidfinalproject.javaClass.financialReport;
import nidfinalproject.javaClass.nidReport;

public class ModifyAndAnalysisNIDRegistrationReportController implements Initializable {

    @FXML
    private TableView<nidReport> nidRegReportTableView;
    @FXML
    private TableColumn<nidReport, LocalDate> reportGenDateColumn;
    @FXML
    private TableColumn<nidReport, String> totalNidRegColumn;
    @FXML
    private TableColumn<nidReport, String> nidCorrectionColumn;
    @FXML
    private TableColumn<nidReport, String> nidCorrectionPendingColumn;
    
    private ArrayList<nidReport> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        list = new ArrayList<nidReport>();
        financialReport b;
        //b = new nidReport();
        reportGenDateColumn.setCellValueFactory(new PropertyValueFactory<nidReport,LocalDate>("reportGenDatePicker"));
        totalNidRegColumn.setCellValueFactory(new PropertyValueFactory<nidReport, String>("totalNidRegistration"));
        nidCorrectionColumn.setCellValueFactory(new PropertyValueFactory<nidReport,String>("nidCorrection"));
        nidCorrectionPendingColumn.setCellValueFactory(new PropertyValueFactory<nidReport,String>("correctionPending"));
        
        //financialReportTableView.setItems(getPeople());    
        
        //Allow first and last name to be edittable
        nidRegReportTableView.setEditable(true);
        totalNidRegColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        nidCorrectionColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        nidCorrectionPendingColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        
        
        //allow the table to select multiple rows at once
        nidRegReportTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }    

    @FXML
    private void totalNidRegistrationEdit(TableColumn.CellEditEvent edittedCell) {
        nidReport personSelected = nidRegReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setTotalNidRegistration(edittedCell.getNewValue().toString());
    }

    @FXML
    private void nidCorrectionEdit(TableColumn.CellEditEvent edittedCell) {
        nidReport personSelected = nidRegReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setNidCorrection(edittedCell.getNewValue().toString());

    }

    @FXML
    private void correctionPendingEdit(TableColumn.CellEditEvent edittedCell) {
        nidReport personSelected = nidRegReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setCorrectionPending(edittedCell.getNewValue().toString());

    }

    @FXML
    private void downloadPdfButton(ActionEvent event) {
         
    }
                

        
        
    
    

    @FXML
    private void backButton(ActionEvent event) throws IOException {
         String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void readObjectTheReport(ActionEvent event) {
        nidRegReportTableView.getItems().clear();
         try {
            nidReport s;
            FileInputStream fis = new FileInputStream("CreateFinalNidRegistrationReport.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
            s = (nidReport) ois.readObject();
            nidRegReportTableView.getItems().add(s);
            }
        
        } catch (Exception ex) {
           
        }        
    }
    
}
