
package nidfinalproject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.Remove;
import nidfinalproject.javaClass.budget;
import nidfinalproject.javaClass.correction;

public class RemoveNidController implements Initializable {
    
      
    
    @FXML
    private TextField birthCertificateNoTextField;
    @FXML
    private DatePicker dateOfBirthDatePicker;
    @FXML
    private DatePicker dateOfDeathDatePicker;
    @FXML
    private TextField deathCertificateNoTextField;
    @FXML
    private TextField nidNumberTextField;
    @FXML
    private TextArea viewRemoveNid;
    
    
    @FXML
    private TextField fullName;
    
    ArrayList<Remove> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<Remove> list;
    }    

    @FXML
    private void writeRemoveNidAndAddToarray(ActionEvent event) {
        Remove std = new Remove(
        fullName.getText(),
        nidNumberTextField.getText(),
        birthCertificateNoTextField.getText(),
        deathCertificateNoTextField.getText(),
        dateOfBirthDatePicker.getValue(),
        dateOfDeathDatePicker.getValue()
        

       );
        
        fullName.setText(null); nidNumberTextField.setText(null); birthCertificateNoTextField.setText(null);

        deathCertificateNoTextField.setText(null); dateOfBirthDatePicker.setValue(null); dateOfDeathDatePicker.setValue(null);
        
        try{
            FileOutputStream fos = new FileOutputStream("RemoveNid.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}


       
    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void readRemoveNid(ActionEvent event) {
        try {
            Remove s;
            FileInputStream fis = new FileInputStream("RemoveNid.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (Remove) ois.readObject();
                //studArr.add((Student) ois.readObject());
                viewRemoveNid.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }

        

    }
    
}
