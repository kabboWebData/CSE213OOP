
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import nidfinalproject.javaClass.blananceSheet;
import nidfinalproject.javaClass.financialReport;
import nidfinalproject.javaClass.transaction;

public class UpdateCurrentFinancialReportController implements Initializable {

    @FXML
    private TableView<financialReport> financialReportTableView;
    @FXML
    private TableColumn<financialReport, LocalDate> reportgenerationDateColumn;
    @FXML
    private TableColumn<financialReport, String> manufacturingColumn;
    @FXML
    private TableColumn<financialReport, String> transportationColumn;
    @FXML
    private TableColumn<financialReport, String> softwareColumn;
    @FXML
    private TableColumn<financialReport, String> taxColumn;
    @FXML
    private TableColumn<financialReport, String> employeeSalaryColumn;
    @FXML
    private DatePicker reportGenDateDatePicker;
    @FXML
    private TextField manufacturingTextField;
    @FXML
    private TextField transportationTextField;
    @FXML
    private TextField softwareTextField;
    @FXML
    private TextField taxTextField;
    @FXML
    private TextField employeeSalaryTextField;
    
    //ArrayList<financialReport> list = new ArrayList<financialReport>();
    
    private ArrayList<financialReport> list;
    


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        list = new ArrayList<financialReport>();
        financialReport b;
        b = new financialReport();

        

        
        
        
        reportgenerationDateColumn.setCellValueFactory(new PropertyValueFactory<financialReport,LocalDate>("reportCreationDate"));
        manufacturingColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("manufacturingCost"));
        transportationColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("transporationFees"));
        softwareColumn.setCellValueFactory(new PropertyValueFactory<financialReport, String>("softwareUpdateCost"));
        taxColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("taxPayment"));
        employeeSalaryColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("totalEmployeeSalary"));

        
    }    

    @FXML
    private void makingClicked(MouseEvent event) {
        manufacturingTextField.setText(null);
    }

    @FXML
    private void transportationClicked(MouseEvent event) {
         transportationTextField.setText(null);

    }

    @FXML
    private void softwareClicked(MouseEvent event) {
        softwareTextField.setText(null);

    }

    @FXML
    private void taxClicked(MouseEvent event) {
        taxTextField.setText(null);
    }

    @FXML
    private void totalEmployeeClicked(MouseEvent event) {
        employeeSalaryTextField.setText(null);
    }



    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void readObjectStreamButton(ActionEvent event) {
         financialReportTableView.getItems().clear();
         try {
            financialReport s;
            FileInputStream fis = new FileInputStream("FinancialReport.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
            s = (financialReport) ois.readObject();
            financialReportTableView.getItems().add(s);
            }
        
        } catch (Exception ex) {
           
        }        


        
        
        }

    @FXML
    private void addToFileButton(ActionEvent event) {
        try {
            FileOutputStream fos = new FileOutputStream("FinancialReport.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            for(financialReport b: list){
                oos.writeObject(b);
            }
            oos.close();
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void addArrayToAllFieldsButton(ActionEvent event) {
        list.add(
                new financialReport(
         
                reportGenDateDatePicker.getValue(),
                manufacturingTextField.getText(),
                transportationTextField.getText(),
                softwareTextField.getText(),
                taxTextField.getText(),
                employeeSalaryTextField.getText()
                )
               
        );
         
          //financialReportTableView.getItems().add(std);
          
                manufacturingTextField.setText(null);
                transportationTextField.setText(null);
                softwareTextField.setText(null);
                taxTextField.setText(null);
                employeeSalaryTextField.setText(null);
                reportGenDateDatePicker.setValue(null);
                
                //std.display();
                
                
                 

    }


        
}
    

