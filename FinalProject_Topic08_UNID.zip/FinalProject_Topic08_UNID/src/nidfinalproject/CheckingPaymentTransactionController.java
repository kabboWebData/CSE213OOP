
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import nidfinalproject.javaClass.Tax;
import nidfinalproject.javaClass.budget;
import nidfinalproject.javaClass.transaction;

public class CheckingPaymentTransactionController implements Initializable {

    @FXML
    private TextField transactionAmmountTxt;
    @FXML
    private DatePicker dateAndTimeDatePicker;
    @FXML
    private ComboBox<String> paymentMethodComboBox;
    @FXML
    private ComboBox<String> transactionSectorComboBox;
    
    
    
     
    @FXML
    private TextArea viewTransaction;
    
    ArrayList<transaction> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        ArrayList<transaction> list;
        
        paymentMethodComboBox.getItems().addAll("Credit Card","David Card","Bkash","Nagad", "Rocket");
        transactionSectorComboBox.getItems().addAll("Transportation","Software Update","Employee Salary","Officer Training Cost", "Others Cost");
       
    }    


    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void creatAndCheckTransactionPayment(ActionEvent event) {
        
        transaction std = new transaction(
        transactionSectorComboBox.getValue(),
        paymentMethodComboBox.getValue(),
        transactionAmmountTxt.getText(),
        dateAndTimeDatePicker.getValue()
     
               
        
       );
         
          transactionSectorComboBox.setValue(null); paymentMethodComboBox.setValue(null); 
        transactionAmmountTxt.setText(null); dateAndTimeDatePicker.setValue(null); 

        try{
            FileOutputStream fos = new FileOutputStream("CheckingPaymentTransaction.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}


        
    }

    @FXML
    private void transactionAmmountClicked(MouseEvent event) {
        transactionAmmountTxt.setText(null);

    }

    @FXML
    private void readCheckingPaymentTransaction(ActionEvent event) {
        try {
             transaction s;
            FileInputStream fis = new FileInputStream("CheckingPaymentTransaction.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (transaction) ois.readObject();
                //studArr.add((Student) ois.readObject());
                viewTransaction.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }

    }
    
}
