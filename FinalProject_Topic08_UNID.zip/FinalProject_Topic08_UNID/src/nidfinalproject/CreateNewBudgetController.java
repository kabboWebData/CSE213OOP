
package nidfinalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import nidfinalproject.javaClass.budget;

public class CreateNewBudgetController implements Initializable {

    @FXML
    private TextField nidCardMakingCostTextField;
    @FXML
    private TextField transportationFeeTextField;
    @FXML
    private TextField softwareUpdateTextField;
    @FXML
    private TextField hrOfficerTrainingTextField;
    @FXML
    private TextField taxTextField;
    @FXML
    private TextField totalEmployeeSalaryTextField;
    @FXML
    private DatePicker budgetPublishedDatePicker;
    @FXML
    private ComboBox<String> budgetYearComboBox;
    
    ArrayList<budget> list;


    @Override
 
    public void initialize(URL url, ResourceBundle rb) {
    ArrayList<budget> list;
    budgetYearComboBox.getItems().addAll("2016","2017","2018","2019", "2020","2021","2022","2023");

        
    }    


    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void makingCostClicked(MouseEvent event) {
        nidCardMakingCostTextField.setText(null);
    }

    @FXML
    private void transportationClicked(MouseEvent event) {
        transportationFeeTextField.setText(null);
        
    }

    @FXML
    private void softwareClicked(MouseEvent event) {
        softwareUpdateTextField.setText(null);
        
    }

    @FXML
    private void hrOfficerClicked(MouseEvent event) {
        hrOfficerTrainingTextField.setText(null);
        
    }

    @FXML
    private void taxClicked(MouseEvent event) {
       taxTextField .setText(null);
        
    }

    @FXML
    private void employeeSalaryClicked(MouseEvent event) {
        totalEmployeeSalaryTextField.setText(null);
    }

    @FXML
    private void saveAllBudgetCriteria(ActionEvent event) {
        
        budget std = new budget(
        Integer.parseInt(nidCardMakingCostTextField.getText()),
        Integer.parseInt(transportationFeeTextField.getText()),
        Integer.parseInt(softwareUpdateTextField.getText()),
        Integer.parseInt(hrOfficerTrainingTextField.getText()),
        Integer.parseInt(taxTextField.getText()),
        Integer.parseInt(totalEmployeeSalaryTextField.getText()),
        budgetYearComboBox.getValue(),
        budgetPublishedDatePicker.getValue()
                          
       );
        
        nidCardMakingCostTextField.setText(null); transportationFeeTextField.setText(null);  softwareUpdateTextField.setText(null);
        hrOfficerTrainingTextField.setText(null); taxTextField.setText(null); totalEmployeeSalaryTextField.setText(null); budgetYearComboBox.setValue(null);
        budgetPublishedDatePicker.setValue(null);
        //std.display();
        
        try{
            FileOutputStream fos = new FileOutputStream("CreatBudget.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}
        
    }
}
    

