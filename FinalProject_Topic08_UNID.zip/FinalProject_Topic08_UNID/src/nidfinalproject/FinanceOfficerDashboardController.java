
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.Tax;


public class FinanceOfficerDashboardController implements Initializable {

    @FXML
    private TextField financeNameTextField;
    @FXML
    private TextField ageTextField;
    @FXML
    private TextField officeIdName;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        financeNameTextField.setText("Asif Mahamood");
        ageTextField.setText("25");
        officeIdName.setText("2310315");
        

        
    }    

    @FXML
    private void createNewBudgetButton(ActionEvent event) throws IOException {
        String path = "CreateNewBudget.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("CreateNewBudget");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void viewAndModifyBudgetButton(ActionEvent event) throws IOException {
        String path = "SeeAndModifyTheBudget.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("SeeAndModifyTheBudget");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void updateCurrentFinancialReportButton(ActionEvent event) throws IOException {
        String path = "UpdateCurrentFinancialReport.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("UpdateCurrentFinancialReport");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void viewAndAnalysisFinancialReportButton(ActionEvent event) throws IOException {
        String path = "ViewAndAnalysisFinancialReport.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("ViewAndAnalysisFinancialReport");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void checkingPaymentTransctionButton(ActionEvent event) throws IOException {
        String path = "CheckingPaymentTransaction.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("CheckingPaymentTransaction");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void createBlananceSheetButton(ActionEvent event) throws IOException {
        String path = "PrepareBlananceSheet.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("PrepareBlananceSheet");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void viewAndAnalysisTaxReportButton(ActionEvent event) throws IOException {
        String path = "TaxReport.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("TaxReport");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void implementFinancialPoliciesButton(ActionEvent event) throws IOException {
        String path = "ReviewAndImplementFinancialPolicies.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("ReviewAndImplementFinancialPolicies");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void logoutButton(ActionEvent event) throws IOException {
        String path = "LoginPage.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

        
    }
    
    
  

    }
               

    

