
package nidfinalproject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import nidfinalproject.javaClass.blananceSheet;
import nidfinalproject.javaClass.nidReport;


public class CreateFinalNidRegistrationReportController implements Initializable {

    @FXML
    private TableView<nidReport> nidRegReportTableView;
    @FXML
    private TableColumn<nidReport, LocalDate> reportGenDateColumn;
    @FXML
    private TableColumn<nidReport, String> totalNidRegColumn;
    @FXML
    private TableColumn<nidReport, String> nidCorrectionColumn;
    @FXML
    private TableColumn<nidReport, String> nidCorrectionPendingColumn;
    @FXML
    private TextField totalNidRegistrationTxt;
    @FXML
    private TextField nidCorrectionTxt;
    @FXML
    private TextField correctionPending;
    @FXML
    private DatePicker reportGenDatePicker;
    
    
    private ArrayList<nidReport> list;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         list = new ArrayList<nidReport>();
        nidReport b;
        //b = new nidReport();
        reportGenDateColumn.setCellValueFactory(new PropertyValueFactory<nidReport,LocalDate>("reportGenDatePicker"));
        totalNidRegColumn.setCellValueFactory(new PropertyValueFactory<nidReport, String>("totalNidRegistration"));
        nidCorrectionColumn.setCellValueFactory(new PropertyValueFactory<nidReport,String>("nidCorrection"));
        nidCorrectionPendingColumn.setCellValueFactory(new PropertyValueFactory<nidReport,String>("correctionPending"));
        


        
    }    

    @FXML
    private void totalNidRegistrationClicked(MouseEvent event) {
        totalNidRegistrationTxt.setText(null);
    }

    @FXML
    private void nidCorrectionClicked(MouseEvent event) {
        nidCorrectionTxt.setText(null);
         
    }

    @FXML
    private void correctionPendingClicked(MouseEvent event) {
        correctionPending.setText(null); 
        
    }

    @FXML
    private void addArrayToAllFieldsButton(ActionEvent event) {
        list.add(
        new nidReport(
                totalNidRegistrationTxt.getText(),
                nidCorrectionTxt.getText(),
                
                //totalExpenditureTextField.getText(),
                correctionPending.getText(),
                reportGenDatePicker.getValue()
               )
        );
        
        
       //blananceSheetTableView.getItems().add(std);
        
        
        
        totalNidRegistrationTxt.setText(null);    
        nidCorrectionTxt.setText(null); 
        correctionPending.setText(null); 
        reportGenDatePicker.setValue(null);
        //std.display();
        

    }

    @FXML
    private void readObjectStreamFileButton(ActionEvent event) {
        nidRegReportTableView.getItems().clear();
         try {
            nidReport s;
            FileInputStream fis = new FileInputStream("CreateFinalNidRegistrationReport.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
            s = (nidReport) ois.readObject();
            nidRegReportTableView.getItems().add(s);
            }
        
        } catch (Exception ex) {
           
        }        
    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void addWriteToFile(ActionEvent event) {
        try {
            FileOutputStream fos = new FileOutputStream("CreateFinalNidRegistrationReport.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            for(nidReport b: list){
                oos.writeObject(b);
            }
            oos.close();
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    }
    

