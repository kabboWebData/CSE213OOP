
package nidfinalproject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import nidfinalproject.javaClass.financialReport;


public class ViewAndAnalysisFinancialReportController implements Initializable {

    @FXML
    private TableView<financialReport> financialReportTableView;
    @FXML
    private TableColumn<financialReport, LocalDate> reportgenerationDateColumn;
    @FXML
    private TableColumn<financialReport, String> manufacturingColumn;
    @FXML
    private TableColumn<financialReport, String> transportationColumn;
    @FXML
    private TableColumn<financialReport, String> softwareColumn;
    @FXML
    private TableColumn<financialReport, String> taxColumn;
    @FXML
    private TableColumn<financialReport, String> employeeSalaryColumn;
    
    private ArrayList<financialReport> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        list = new ArrayList<financialReport>();
        financialReport b;
        b = new financialReport();

        

        
        
        
        reportgenerationDateColumn.setCellValueFactory(new PropertyValueFactory<financialReport,LocalDate>("reportCreationDate"));
        manufacturingColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("manufacturingCost"));
        transportationColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("transporationFees"));
        softwareColumn.setCellValueFactory(new PropertyValueFactory<financialReport, String>("softwareUpdateCost"));
        taxColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("taxPayment"));
        employeeSalaryColumn.setCellValueFactory(new PropertyValueFactory<financialReport,String>("totalEmployeeSalary"));

        //financialReportTableView.setItems(getPeople());    
        
        //Allow first and last name to be edittable
        financialReportTableView.setEditable(true);
        manufacturingColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        transportationColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        softwareColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        taxColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        employeeSalaryColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        
        
        //allow the table to select multiple rows at once
        financialReportTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        
    }    

    @FXML
    private void downloadReportPdfButton(ActionEvent event) {
    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void readObjectFinanacialReport(ActionEvent event) {
        
        financialReportTableView.getItems().clear();
         try {
            financialReport s;
            FileInputStream fis = new FileInputStream("FinancialReport.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
            s = (financialReport) ois.readObject();
            financialReportTableView.getItems().add(s);
            }
        
        } catch (Exception ex) {
           
        }        



    }

    @FXML
    private void manufacturingCostEdit(TableColumn.CellEditEvent edittedCell) {
        financialReport personSelected = financialReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setManufacturingCost(edittedCell.getNewValue().toString());
    }

    @FXML
    private void transportationFeeEdit(TableColumn.CellEditEvent edittedCell) {
        financialReport personSelected = financialReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setTransporationFees(edittedCell.getNewValue().toString());
    }

    @FXML
    private void softwareUpdateEdit(TableColumn.CellEditEvent edittedCell) {
        financialReport personSelected = financialReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setSoftwareUpdateCost(edittedCell.getNewValue().toString());
    }

    @FXML
    private void taxEdit(TableColumn.CellEditEvent edittedCell) {
        financialReport personSelected = financialReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setTaxPayment(edittedCell.getNewValue().toString());
    }

    @FXML
    private void employeeSalaryEdit(TableColumn.CellEditEvent edittedCell) {
        financialReport personSelected = financialReportTableView.getSelectionModel().getSelectedItem();
        personSelected.setTotalEmployeeSalary(edittedCell.getNewValue().toString());
    }
    
}
