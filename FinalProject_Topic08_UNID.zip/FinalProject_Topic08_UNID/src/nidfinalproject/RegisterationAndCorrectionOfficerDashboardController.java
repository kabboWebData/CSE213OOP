/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nidfinalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author KAWSHIK
 */
public class RegisterationAndCorrectionOfficerDashboardController implements Initializable {

    @FXML
    private TextField nameTxt;
    @FXML
    private TextField ageTxt;
    @FXML
    private TextField officeTxt;
    @FXML
    private TextField salaryTxt;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        nameTxt.setText("Faisal Ahsan");
        ageTxt.setText("31");
        officeTxt.setText("1831590");
        salaryTxt.setText("35000");
        
        
    }    

    @FXML
    private void removeNidDeadButton(ActionEvent event) throws IOException {
        String path = "RemoveNid.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("RemoveNidDeadCitizen");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void updateWrittenInfoButton(ActionEvent event) throws IOException {
        String path = "UpdateWrittenInformation.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("UpdateWrittenInformation");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void updateImageButton(ActionEvent event) throws IOException {
        String path = "UpdateImage.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("UpdateImage");
        window.setScene(scene);
        window.show();
    }

   

    

    

    @FXML
    private void approveReRegistrationButton(ActionEvent event) throws IOException {
        String path = "ApproveReRegistration.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("ApproveReRegistration");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void sendNotificatonButton(ActionEvent event) throws IOException {
        String path = "SendNotificationToCitizen.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("SendNotificationToCitizen");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void logoutButton(ActionEvent event) throws IOException {
        String path = "LoginPage.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("RegistrationAndCorrectionOfficerDashBoard");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void createFinalNidRegistrationReport(ActionEvent event) throws IOException {
        String path = "CreateFinalNidRegistrationReport.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("CreateFinalNidRegistrationReport");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void modifyAndAnalysisNidRegistrationReport(ActionEvent event) throws IOException {
        String path = "ModifyAndAnalysisNIDRegistrationReport.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("ModifyAndAnalysisNIDRegistrationReport");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void canApproveRetrieveLostNidCard(ActionEvent event) throws IOException {
        String path = "CanApproveRetrieveLostNidCard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("CanApproveRetrieveLostNidCard");
        window.setScene(scene);
        window.show();
    }
    
}
