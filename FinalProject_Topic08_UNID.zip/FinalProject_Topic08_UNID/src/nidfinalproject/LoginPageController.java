/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nidfinalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author KAWSHIK
 */
public class LoginPageController implements Initializable {

    @FXML
    private TextField userIdTextField;
    @FXML
    private TextField passwordTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
            }    

    @FXML
    private void loginButton(ActionEvent event) throws IOException {
        String path = "FinanceAndRegistrationCorrectionOfficer.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
        
        
        
        
        String userId = userIdTextField.getText();
        String password = passwordTextField.getText();

        if (isValid(userId, password)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Login Successful");
            alert.setHeaderText(null);
            alert.setContentText("You have successfully logged in.");
            alert.showAndWait();

            // TODO: navigate to the next page
        } 
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Error");
            alert.setHeaderText(null);
            alert.setContentText("Login Successfull.");
            alert.showAndWait();
            //Invalid user ID or password
        }
    }

    private boolean isValid(String userId, String password) {
        // TODO: implement your own validation logic
        return "admin".equals(userId) && "password".equals(password);
    }
    
    
    
 }

        

