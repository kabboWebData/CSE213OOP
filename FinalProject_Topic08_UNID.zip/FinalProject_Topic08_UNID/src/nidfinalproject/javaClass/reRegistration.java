
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;


public class reRegistration implements Serializable {
    String name, registrationOver, reRegistrationFee,address,gender,validityCheck;
    int nidNumber;
    LocalDate dateOfBirth;

    public reRegistration(String name, String registrationOver, String reRegistrationFee, String address, String gender, String validityCheck, int nidNumber, LocalDate dateOfBirth) {
        this.name = name;
        this.registrationOver = registrationOver;
        this.reRegistrationFee = reRegistrationFee;
        this.address = address;
        this.gender = gender;
        this.validityCheck = validityCheck;
        this.nidNumber = nidNumber;
        this.dateOfBirth = dateOfBirth;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegistrationOver() {
        return registrationOver;
    }

    public void setRegistrationOver(String registrationOver) {
        this.registrationOver = registrationOver;
    }

    public String getReRegistrationFee() {
        return reRegistrationFee;
    }

    public void setReRegistrationFee(String reRegistrationFee) {
        this.reRegistrationFee = reRegistrationFee;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getValidityCheck() {
        return validityCheck;
    }

    public void setValidityCheck(String validityCheck) {
        this.validityCheck = validityCheck;
    }

    public int getNidNumber() {
        return nidNumber;
    }

    public void setNidNumber(int nidNumber) {
        this.nidNumber = nidNumber;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toString() {
        return "reRegistration{" + "name=" + name + ", registrationOver=" + registrationOver + ", reRegistrationFee=" + reRegistrationFee + ", address=" + address + ", gender=" + gender + ", validityCheck=" + validityCheck + ", nidNumber=" + nidNumber + ", dateOfBirth=" + dateOfBirth + '}';
    }
    
    

   }
