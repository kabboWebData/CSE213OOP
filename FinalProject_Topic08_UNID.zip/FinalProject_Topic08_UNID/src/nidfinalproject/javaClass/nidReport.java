
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

public class nidReport implements Serializable {
    String totalNidRegistration, nidCorrection, correctionPending;
    LocalDate reportGenDatePicker;

    public nidReport(String totalNidRegistration, String nidCorrection, String correctionPending, LocalDate reportGenDatePicker) {
        this.totalNidRegistration = totalNidRegistration;
        this.nidCorrection = nidCorrection;
        this.correctionPending = correctionPending;
        this.reportGenDatePicker = reportGenDatePicker;
    }

    public nidReport() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getTotalNidRegistration() {
        return totalNidRegistration;
    }

    public void setTotalNidRegistration(String totalNidRegistration) {
        this.totalNidRegistration = totalNidRegistration;
    }

    public String getNidCorrection() {
        return nidCorrection;
    }

    public void setNidCorrection(String nidCorrection) {
        this.nidCorrection = nidCorrection;
    }

    public String getCorrectionPending() {
        return correctionPending;
    }

    public void setCorrectionPending(String correctionPending) {
        this.correctionPending = correctionPending;
    }

    public LocalDate getReportGenDatePicker() {
        return reportGenDatePicker;
    }

    public void setReportGenDatePicker(LocalDate reportGenDatePicker) {
        this.reportGenDatePicker = reportGenDatePicker;
    }

    @Override
    public String toString() {
        return "nidReport{" + "totalNidRegistration=" + totalNidRegistration + ", nidCorrection=" + nidCorrection + ", correctionPending=" + correctionPending + ", reportGenDatePicker=" + reportGenDatePicker + '}';
    }

           
}
