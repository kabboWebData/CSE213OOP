
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

public class budget implements Serializable{
    int nidCardMakingCost, transportationFees, softwareUpdate, hrOfficerTrainingCost, tax, totalEmployeeSalary;
    String budgetYear;
    LocalDate budgetPublishedDate;

    public budget(int nidCardMakingCost, int transportationFees, int softwareUpdate, int hrOfficerTrainingCost, int tax, int totalEmployeeSalary, String budgetYear, LocalDate budgetPublishedDate) {
        this.nidCardMakingCost = nidCardMakingCost;
        this.transportationFees = transportationFees;
        this.softwareUpdate = softwareUpdate;
        this.hrOfficerTrainingCost = hrOfficerTrainingCost;
        this.tax = tax;
        this.totalEmployeeSalary = totalEmployeeSalary;
        this.budgetYear = budgetYear;
        this.budgetPublishedDate = budgetPublishedDate;
    }

    public int getNidCardMakingCost() {
        return nidCardMakingCost;
    }

    public void setNidCardMakingCost(int nidCardMakingCost) {
        this.nidCardMakingCost = nidCardMakingCost;
    }

    public int getTransportationFees() {
        return transportationFees;
    }

    public void setTransportationFees(int transportationFees) {
        this.transportationFees = transportationFees;
    }

    public int getSoftwareUpdate() {
        return softwareUpdate;
    }

    public void setSoftwareUpdate(int softwareUpdate) {
        this.softwareUpdate = softwareUpdate;
    }

    public int getHrOfficerTrainingCost() {
        return hrOfficerTrainingCost;
    }

    public void setHrOfficerTrainingCost(int hrOfficerTrainingCost) {
        this.hrOfficerTrainingCost = hrOfficerTrainingCost;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    public int getTotalEmployeeSalary() {
        return totalEmployeeSalary;
    }

    public void setTotalEmployeeSalary(int totalEmployeeSalary) {
        this.totalEmployeeSalary = totalEmployeeSalary;
    }

    public String getBudgetYear() {
        return budgetYear;
    }

    public void setBudgetYear(String budgetYear) {
        this.budgetYear = budgetYear;
    }

    public LocalDate getBudgetPublishedDate() {
        return budgetPublishedDate;
    }

    public void setBudgetPublishedDate(LocalDate budgetPublishedDate) {
        this.budgetPublishedDate = budgetPublishedDate;
    }

    @Override
    public String toString() {
        return "budget{" + "nidCardMakingCost=" + nidCardMakingCost + ", transportationFees=" + transportationFees + ", softwareUpdate=" + softwareUpdate + ", hrOfficerTrainingCost=" + hrOfficerTrainingCost + ", tax=" + tax + ", totalEmployeeSalary=" + totalEmployeeSalary + ", budgetYear=" + budgetYear + ", budgetPublishedDate=" + budgetPublishedDate + '}';
    }

    //public void display() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}

    public void submitReport() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

        
}
