
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

public class financialReport implements Serializable{
    LocalDate reportCreationDate;
    String manufacturingCost, transporationFees, softwareUpdateCost, taxPayment,totalEmployeeSalary;

    public financialReport() {
    }
    
    

    public financialReport(LocalDate reportCreationDate, String manufacturingCost, String transporationFees, String softwareUpdateCost, String taxPayment, String totalEmployeeSalary) {
        this.reportCreationDate = reportCreationDate;
        this.manufacturingCost = manufacturingCost;
        this.transporationFees = transporationFees;
        this.softwareUpdateCost = softwareUpdateCost;
        this.taxPayment = taxPayment;
        this.totalEmployeeSalary = totalEmployeeSalary;
    }

    public LocalDate getReportCreationDate() {
        return reportCreationDate;
    }

    public void setReportCreationDate(LocalDate reportCreationDate) {
        this.reportCreationDate = reportCreationDate;
    }

    public String getManufacturingCost() {
        return manufacturingCost;
    }

    public void setManufacturingCost(String manufacturingCost) {
        this.manufacturingCost = manufacturingCost;
    }

    public String getTransporationFees() {
        return transporationFees;
    }

    public void setTransporationFees(String transporationFees) {
        this.transporationFees = transporationFees;
    }

    public String getSoftwareUpdateCost() {
        return softwareUpdateCost;
    }

    public void setSoftwareUpdateCost(String softwareUpdateCost) {
        this.softwareUpdateCost = softwareUpdateCost;
    }

    public String getTaxPayment() {
        return taxPayment;
    }

    public void setTaxPayment(String taxPayment) {
        this.taxPayment = taxPayment;
    }

    public String getTotalEmployeeSalary() {
        return totalEmployeeSalary;
    }

    public void setTotalEmployeeSalary(String totalEmployeeSalary) {
        this.totalEmployeeSalary = totalEmployeeSalary;
    }

    @Override
    public String toString() {
        return "financialReport{" + "reportCreationDate=" + reportCreationDate + ", manufacturingCost=" + manufacturingCost + ", transporationFees=" + transporationFees + ", softwareUpdateCost=" + softwareUpdateCost + ", taxPayment=" + taxPayment + ", totalEmployeeSalary=" + totalEmployeeSalary + '}';
    }

    //public void display() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    
    

    }
