
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;
import javafx.beans.property.SimpleStringProperty;


public class blananceSheet implements Serializable{
    String budget; 
    String totalExpenditure;
    String totalTransaction;
    LocalDate genDate;

    public blananceSheet() {
    }

    public blananceSheet(String budget, String totalExpenditure, String totalTransaction, LocalDate genDate) {
        this.budget = budget;
        this.totalExpenditure = totalExpenditure;
        this.totalTransaction = totalTransaction;
        this.genDate = genDate;
    }

    public String getBudget() {
        return budget;
    }

    public void setBudget(String budget) {
        this.budget = budget;
    }

    public String getTotalExpenditure() {
        return totalExpenditure;
    }

    public void setTotalExpenditure(String totalExpenditure) {
        this.totalExpenditure = totalExpenditure;
    }

    public String getTotalTransaction() {
        return totalTransaction;
    }

    public void setTotalTransaction(String totalTransaction) {
        this.totalTransaction = totalTransaction;
    }

    public LocalDate getGenDate() {
        return genDate;
    }

    public void setGenDate(LocalDate genDate) {
        this.genDate = genDate;
    }

    @Override
    public String toString() {
        return "blananceSheet{" + "budget=" + budget + ", totalExpenditure=" + totalExpenditure + ", totalTransaction=" + totalTransaction + ", genDate=" + genDate + '}';
    }

    //public void display() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}


    
    

       
    

    }
