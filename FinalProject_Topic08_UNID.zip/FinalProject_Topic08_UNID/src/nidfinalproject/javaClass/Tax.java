
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;


public class Tax implements Serializable{
    String khatianNumber, landTax, taxStatus, dueAmmountTax;
    LocalDate taxSubmissionDate;

    public Tax(String khatianNumber, String landTax, String taxStatus, String dueAmmountTax, LocalDate taxSubmissionDate) {
        this.khatianNumber = khatianNumber;
        this.landTax = landTax;
        this.taxStatus = taxStatus;
        this.dueAmmountTax = dueAmmountTax;
        this.taxSubmissionDate = taxSubmissionDate;
    }

    public String getKhatianNumber() {
        return khatianNumber;
    }

    public void setKhatianNumber(String khatianNumber) {
        this.khatianNumber = khatianNumber;
    }

    public String getLandTax() {
        return landTax;
    }

    public void setLandTax(String landTax) {
        this.landTax = landTax;
    }

    public String getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(String taxStatus) {
        this.taxStatus = taxStatus;
    }

    public String getDueAmmountTax() {
        return dueAmmountTax;
    }

    public void setDueAmmountTax(String dueAmmountTax) {
        this.dueAmmountTax = dueAmmountTax;
    }

    public LocalDate getTaxSubmissionDate() {
        return taxSubmissionDate;
    }

    public void setTaxSubmissionDate(LocalDate taxSubmissionDate) {
        this.taxSubmissionDate = taxSubmissionDate;
    }

    @Override
    public String toString() {
        return "Tax{" + "khatianNumber=" + khatianNumber + ", landTax=" + landTax + ", taxStatus=" + taxStatus + ", dueAmmountTax=" + dueAmmountTax + ", taxSubmissionDate=" + taxSubmissionDate + '}';
    }
    
    public String gettaxStatus(){
        return taxStatus;
    }
        
        
    

           
}
