
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

public class Remove implements Serializable {
    String fullName, nidNumber, birthCertificateNumber, deathCertificateNumber;
    LocalDate dateOfBirth, dateOfDeath;

    public Remove(String fullName, String nidNumber, String birthCertificateNumber, String deathCertificateNumber, LocalDate dateOfBirth, LocalDate dateOfDeath) {
        this.fullName = fullName;
        this.nidNumber = nidNumber;
        this.birthCertificateNumber = birthCertificateNumber;
        this.deathCertificateNumber = deathCertificateNumber;
        this.dateOfBirth = dateOfBirth;
        this.dateOfDeath = dateOfDeath;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNidNumber() {
        return nidNumber;
    }

    public void setNidNumber(String nidNumber) {
        this.nidNumber = nidNumber;
    }

    public String getBirthCertificateNumber() {
        return birthCertificateNumber;
    }

    public void setBirthCertificateNumber(String birthCertificateNumber) {
        this.birthCertificateNumber = birthCertificateNumber;
    }

    public String getDeathCertificateNumber() {
        return deathCertificateNumber;
    }

    public void setDeathCertificateNumber(String deathCertificateNumber) {
        this.deathCertificateNumber = deathCertificateNumber;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfDeath() {
        return dateOfDeath;
    }

    public void setDateOfDeath(LocalDate dateOfDeath) {
        this.dateOfDeath = dateOfDeath;
    }

    @Override
    public String toString() {
        return "Remove{" + "fullName=" + fullName + ", nidNumber=" + nidNumber + ", birthCertificateNumber=" + birthCertificateNumber + ", deathCertificateNumber=" + deathCertificateNumber + ", dateOfBirth=" + dateOfBirth + ", dateOfDeath=" + dateOfDeath + '}';
    }
    
    

   }
