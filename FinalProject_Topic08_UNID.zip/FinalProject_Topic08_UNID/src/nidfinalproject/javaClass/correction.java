
package nidfinalproject.javaClass;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type;
import java.io.Serializable;
import java.time.LocalDate;


public class correction implements Serializable{
    String  firstName, lastName, fullName, permanentAddress, presentAddress;
    LocalDate dateOfBirth;

    public correction(String firstName, String lastName, String fullName, String permanentAddress, String presentAddress, LocalDate dateOfBirth) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.fullName = fullName;
        this.permanentAddress = permanentAddress;
        this.presentAddress = presentAddress;
        this.dateOfBirth = dateOfBirth;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toString() {
        return "correction{" + "firstName=" + firstName + ", lastName=" + lastName + ", fullName=" + fullName + ", permanentAddress=" + permanentAddress + ", presentAddress=" + presentAddress + ", dateOfBirth=" + dateOfBirth + '}';
    }

        

    }
