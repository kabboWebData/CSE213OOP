
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;


public class transaction implements Serializable{
    String transactionSector, paymentMethod, transactionAmmount;
    LocalDate dateTimeOfTransaction;

    public transaction(String transactionSector, String paymentMethod, String transactionAmmount, LocalDate dateTimeOfTransaction) {
        this.transactionSector = transactionSector;
        this.paymentMethod = paymentMethod;
        this.transactionAmmount = transactionAmmount;
        this.dateTimeOfTransaction = dateTimeOfTransaction;
    }

    public transaction(String value, String value0, String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getTransactionSector() {
        return transactionSector;
    }

    public void setTransactionSector(String transactionSector) {
        this.transactionSector = transactionSector;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getTransactionAmmount() {
        return transactionAmmount;
    }

    public void setTransactionAmmount(String transactionAmmount) {
        this.transactionAmmount = transactionAmmount;
    }

    public LocalDate getDateTimeOfTransaction() {
        return dateTimeOfTransaction;
    }

    public void setDateTimeOfTransaction(LocalDate dateTimeOfTransaction) {
        this.dateTimeOfTransaction = dateTimeOfTransaction;
    }

    @Override
    public String toString() {
        return "transaction{" + "transactionSector=" + transactionSector + ", paymentMethod=" + paymentMethod + ", transactionAmmount=" + transactionAmmount + ", dateTimeOfTransaction=" + dateTimeOfTransaction + '}';
    }

        
    
    
    
}
