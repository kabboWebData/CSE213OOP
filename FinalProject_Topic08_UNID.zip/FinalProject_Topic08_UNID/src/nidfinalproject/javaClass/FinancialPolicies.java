
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

public class FinancialPolicies implements Serializable{
    String budgetIncreased, whichCaseBudgetIncreased, debtManagement, costAllocation;
    LocalDate selectReviewDate;

    public FinancialPolicies(String budgetIncreased, String whichCaseBudgetIncreased, String debtManagement, String costAllocation, LocalDate selectReviewDate) {
        this.budgetIncreased = budgetIncreased;
        this.whichCaseBudgetIncreased = whichCaseBudgetIncreased;
        this.debtManagement = debtManagement;
        this.costAllocation = costAllocation;
        this.selectReviewDate = selectReviewDate;
    }

    public String getBudgetIncreased() {
        return budgetIncreased;
    }

    public void setBudgetIncreased(String budgetIncreased) {
        this.budgetIncreased = budgetIncreased;
    }

    public String getWhichCaseBudgetIncreased() {
        return whichCaseBudgetIncreased;
    }

    public void setWhichCaseBudgetIncreased(String whichCaseBudgetIncreased) {
        this.whichCaseBudgetIncreased = whichCaseBudgetIncreased;
    }

    public String getDebtManagement() {
        return debtManagement;
    }

    public void setDebtManagement(String debtManagement) {
        this.debtManagement = debtManagement;
    }

    public String getCostAllocation() {
        return costAllocation;
    }

    public void setCostAllocation(String costAllocation) {
        this.costAllocation = costAllocation;
    }

    public LocalDate getSelectReviewDate() {
        return selectReviewDate;
    }

    public void setSelectReviewDate(LocalDate selectReviewDate) {
        this.selectReviewDate = selectReviewDate;
    }

    @Override
    public String toString() {
        return "FinancialPolicies{" + "budgetIncreased=" + budgetIncreased + ", whichCaseBudgetIncreased=" + whichCaseBudgetIncreased + ", debtManagement=" + debtManagement + ", costAllocation=" + costAllocation + ", selectReviewDate=" + selectReviewDate + '}';
    }
    
    
        public String getbudgetIncreased(){
        return budgetIncreased;
    }
        
        
        public String getdebtManagement(){
        return debtManagement;
    }
            
        public String getcostAllocation(){
        return costAllocation;
    }
                
        public LocalDate getselectReviewDate(){
        return selectReviewDate;
    }
    
    
    
    
}
