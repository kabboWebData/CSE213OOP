/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author KAWSHIK
 */
public class FinanceOfficer extends budget implements  Serializable{
    
    public FinanceOfficer(int nidCardMakingCost, int transportationFees, int softwareUpdate, int hrOfficerTrainingCost, int tax, int totalEmployeeSalary, String budgetYear, LocalDate budgetPublishedDate) {
        super(nidCardMakingCost, transportationFees, softwareUpdate, hrOfficerTrainingCost, tax, totalEmployeeSalary, budgetYear, budgetPublishedDate);
    }
    
}
