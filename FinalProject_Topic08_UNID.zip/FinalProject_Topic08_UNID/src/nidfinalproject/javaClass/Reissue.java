
package nidfinalproject.javaClass;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


public class Reissue implements Serializable{
    String name, nidNumber, gdNumber, thanaName, district;
    LocalDate dateOfGD, DateOfBirth;

    public Reissue(String name, String nidNumber, String gdNumber, String thanaName, String district, LocalDate dateOfGD, LocalDate DateOfBirth) {
        this.name = name;
        this.nidNumber = nidNumber;
        this.gdNumber = gdNumber;
        this.thanaName = thanaName;
        this.district = district;
        this.dateOfGD = dateOfGD;
        this.DateOfBirth = DateOfBirth;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNidNumber() {
        return nidNumber;
    }

    public void setNidNumber(String nidNumber) {
        this.nidNumber = nidNumber;
    }

    public String getGdNumber() {
        return gdNumber;
    }

    public void setGdNumber(String gdNumber) {
        this.gdNumber = gdNumber;
    }

    public String getThanaName() {
        return thanaName;
    }

    public void setThanaName(String thanaName) {
        this.thanaName = thanaName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public LocalDate getDateOfGD() {
        return dateOfGD;
    }

    public void setDateOfGD(LocalDate dateOfGD) {
        this.dateOfGD = dateOfGD;
    }

    public LocalDate getDateOfBirth() {
        return DateOfBirth;
    }

    public void setDateOfBirth(LocalDate DateOfBirth) {
        this.DateOfBirth = DateOfBirth;
    }

    @Override
    public String toString() {
        return "Reissue{" + "name=" + name + ", nidNumber=" + nidNumber + ", gdNumber=" + gdNumber + ", thanaName=" + thanaName + ", district=" + district + ", dateOfGD=" + dateOfGD + ", DateOfBirth=" + DateOfBirth + '}';
    }
    
    public LocalDate getdateOfGD(){
        return dateOfGD;
    }
    
    
    
}
