
package nidfinalproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FinanceAndRegistrationCorrectionOfficerController implements Initializable {

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void financeOfficerButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceOfficerDashboard");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void registrationAndCorrectionOfficerButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("RegisterationAndCorrectionOfficerDashboard");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void rerchAndDevolepmentOfficer(ActionEvent event) throws IOException {
        String path = "RnDdash.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("RegisterationAndCorrectionOfficerDashboard");
        window.setScene(scene);
        window.show();


    }

    @FXML
    private void citizenDesh(ActionEvent event) {
    }

    @FXML
    private void hroDesh(ActionEvent event) {
    }

    @FXML
    private void fieldOfficerDesh(ActionEvent event) {
    }

    @FXML
    private void distributionDesh(ActionEvent event) {
    }

    @FXML
    private void supplierDesh(ActionEvent event) {
    }

    @FXML
    private void logoutButton(ActionEvent event) throws IOException {
        String path = "LoginPage.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("RegisterationAndCorrectionOfficerDashboard");
        window.setScene(scene);
        window.show();

    }
    
}
