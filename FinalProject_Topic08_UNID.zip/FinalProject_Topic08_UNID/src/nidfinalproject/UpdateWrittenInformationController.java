
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.budget;
import nidfinalproject.javaClass.correction;
import nidfinalproject.javaClass.transaction;

public class UpdateWrittenInformationController implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private DatePicker dateOfBirthDatePicker;
    @FXML
    private TextField firstNameTextField;
    @FXML
    private TextField lastNameTextField;
    @FXML
    private TextField fullNameTextField;
    @FXML
    private TextField permanentAddressTextField;
    @FXML
    private TextField presentAddressTextField;
    
    //ArrayList<correction> list = new ArrayList<correction>();
    @FXML
    private TextArea showTextArea;
    
    ArrayList<correction> list;


    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<correction> list;

       
    }    

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "RegisterationAndCorrectionOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }



    @FXML
    private void updateAndWriteTheInfoButton(ActionEvent event) {
       correction std = new correction(
       firstNameTextField.getText(),
       lastNameTextField.getText(),
       fullNameTextField.getText(),
       permanentAddressTextField.getText(),
       presentAddressTextField.getText(),
       dateOfBirthDatePicker.getValue()
        
       );
         
          firstNameTextField.setText(null); lastNameTextField.setText(null);  fullNameTextField.setText(null);
        permanentAddressTextField.setText(null); presentAddressTextField.setText(null); dateOfBirthDatePicker.setValue(null); 

        try{
            FileOutputStream fos = new FileOutputStream("UpdateTheWrittenInformation.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}
        
 

    }

    @FXML
    private void readTheUpdateInformation(ActionEvent event) {
        try {
             budget s;
            FileInputStream fis = new FileInputStream("CreatBudget.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (budget) ois.readObject();
                //studArr.add((Student) ois.readObject());
                showTextArea.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }

        

    }
    
}
