
package nidfinalproject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import nidfinalproject.javaClass.Tax;
import nidfinalproject.javaClass.correction;

public class TaxReportController implements Initializable {

    @FXML
    private TextField khatianNumberTextField;
    @FXML
    private TextField landTaxTextField;
    @FXML
    private TextField dueAmmountTextField;
    @FXML
    private DatePicker taxSubmissionDatePicker;
    @FXML
    private TextArea viewTax;
    @FXML
    private ComboBox<String> taxSateCombobox;
    
    ArrayList<Tax> list;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList<Tax> list;
        
        taxSateCombobox.getItems().addAll("Paid","Unpaid");
        
    }    

    @FXML
    private void saveAndWriteTaxReportButton(ActionEvent event) {
        Tax std = new Tax(
       khatianNumberTextField.getText(),
       landTaxTextField.getText(),
       dueAmmountTextField.getText(),
       taxSateCombobox.getValue(),
       taxSubmissionDatePicker.getValue()
       
        
       );
         
          khatianNumberTextField.setText(null); landTaxTextField.setText(null);  dueAmmountTextField.setText(null);
        taxSateCombobox.setValue(null); taxSubmissionDatePicker.setValue(null);  

        try{
            FileOutputStream fos = new FileOutputStream("ViewTaxReport.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(std);
            oos.close();
        }
        
        catch(Exception e){}
        

    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void readTaxReportButton(ActionEvent event) {
        try {
             Tax s;
            FileInputStream fis = new FileInputStream("ViewTaxReport.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (Tax) ois.readObject();
                //studArr.add((Student) ois.readObject());
                viewTax.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }

    }
    
}
