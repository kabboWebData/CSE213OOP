
package nidfinalproject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import nidfinalproject.javaClass.budget;
import nidfinalproject.javaClass.correction;

public class SeeAndModifyTheBudgetController implements Initializable {

    @FXML
    private TextArea viewAllBudgetTextArea;
    

    
                ArrayList<budget> list;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                ArrayList<budget> list;

    }    

    @FXML
    private void modifyBudgetButton(ActionEvent event) throws IOException {
         String path = "ModifyBudget.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

    }

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();

       
    }

    @FXML
    private void objectStreamReadViewBudget(ActionEvent event) {
          try {
             budget s;
            FileInputStream fis = new FileInputStream("CreatBudget.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            while(true){
                s = (budget) ois.readObject();
                //studArr.add((Student) ois.readObject());
                viewAllBudgetTextArea.appendText(s.toString()+"\n");
                //outputTxtArea.appendText(s+"\n");
            }
            //ois.close();
                       
        }
        catch(RuntimeException e){
            e.printStackTrace();
             //
        }
        catch (Exception ex) {
                      
        }

    }
    
}
