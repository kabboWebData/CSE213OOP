
package nidfinalproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import nidfinalproject.javaClass.blananceSheet;
import nidfinalproject.javaClass.financialReport;

public class PrepareBlananceSheetController implements Initializable {

    @FXML
    private TableView<blananceSheet> blananceSheetTableView;
    @FXML
    private TableColumn<blananceSheet, LocalDate> blananceGenDateColumn;
    @FXML
    private TableColumn<blananceSheet, String> budgetColumn;
    @FXML
    private TableColumn<blananceSheet, String> totalExpenditureColumn;
    @FXML
    private TableColumn<blananceSheet, String> totalTransactionColumn;
    @FXML
    private DatePicker blananceGenDateDatePicker;
    @FXML
    private TextField budgetTextField;
    @FXML
    private TextField totalExpenditureTextField;
    @FXML
    private TextField totalTransactionTextField;
    
    private ArrayList<blananceSheet> list;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        list = new ArrayList<blananceSheet>();
        blananceSheet b;
        b = new blananceSheet();
            
        blananceGenDateColumn.setCellValueFactory(new PropertyValueFactory<blananceSheet,LocalDate>("genDate"));
        budgetColumn.setCellValueFactory(new PropertyValueFactory<blananceSheet, String>("budget"));
        totalExpenditureColumn.setCellValueFactory(new PropertyValueFactory<blananceSheet,String>("totalExpenditure"));
        totalTransactionColumn.setCellValueFactory(new PropertyValueFactory<blananceSheet,String>("totalTransaction"));

       
    }    

    @FXML
    private void backButton(ActionEvent event) throws IOException {
        String path = "FinanceOfficerDashboard.fxml";
        Parent root = FXMLLoader.load(getClass().getResource(path));
        Scene scene = new Scene(root);
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.setTitle("FinanceAndRegistrationCorrectionOfficer");
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void readObjectStreamFile(ActionEvent event) {
        blananceSheetTableView.getItems().clear();
         try {
            blananceSheet s;
            FileInputStream fis = new FileInputStream("PrepareBlananceSheet.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
            s = (blananceSheet) ois.readObject();
            blananceSheetTableView.getItems().add(s);
            }
        
        } catch (Exception ex) {
           
        }        

        
               }


    @FXML
    private void generationClicked(MouseEvent event) {
      // blananceGenDateDatePicker.setValue(null);

    }

    @FXML
    private void budgetClicked(MouseEvent event) {
        budgetTextField.setText(null);
    }

    @FXML
    private void expenditureClicked(MouseEvent event) {
        totalExpenditureTextField.setText(null);
    }

    @FXML
    private void transactionClicked(MouseEvent event) {
        totalTransactionTextField.setText(null);
    }

  

    @FXML
    private void addArrayToAllFieldsButton(ActionEvent event) {

        
        list.add(
                new blananceSheet(
                budgetTextField.getText(),
                totalExpenditureTextField.getText(),
                
                //totalExpenditureTextField.getText(),
                totalTransactionTextField.getText(),
                blananceGenDateDatePicker.getValue()
                )
        );
        
        
       //blananceSheetTableView.getItems().add(std);
        
        
        
        budgetTextField.setText(null);    
        totalExpenditureTextField.setText(null); 
        totalTransactionTextField.setText(null); 
        blananceGenDateDatePicker.setValue(null);
        //std.display();
        
    }

    @FXML
    private void addWriteToFile(ActionEvent event) {
        try {
            FileOutputStream fos = new FileOutputStream("PrepareBlananceSheet.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            for(blananceSheet b: list){
                oos.writeObject(b);
            }
            oos.close();
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }


}

    

